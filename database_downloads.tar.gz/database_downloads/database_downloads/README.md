# Raw Databases Downloads

This folder contains raw data downloaded from databases that cannot be donwloaded from scripts. Each subfolder is named according to the database.

## Folder Structure
- `planteomeGene/`
  - `select`: Association of planteome genes and the different annotation (GO,PO,..)
- `planteomeTerms/`
  - `select`: Association of planteome annoation and description
- `PNRD/`
  - `PNRD_sly_targets.txt`: Targets of the microRNAs for the *S. lycopersicum* species found in PNRD.
- `mercator/`
  - `Mercator_annotation_Sly_4_1.txt`: Mercator annotation from protein sequences of ITAG4.1 using Mercator4 v7.0

## Data Sources
- `Planteome`
  - Source : https://planteome.org/
- `PNRD`
  - Source: http://structuralbiology.cau.edu.cn/PNRD/index.php
- `Mercator`
  - Source: https://www.plabipd.de/mercator_main.html