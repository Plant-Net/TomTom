# Raw Databases Downloads

This folder contains raw data downloaded from databases that cannot be donwloaded from scripts. Each subfolder is named according to the database.

## Folder Structure
- `planteomeGene/`
  - `select`: Association of planteome genes and the different annotation (GO,PO,..)
- `planteomeTerms/`
  - `select`: Association of planteome annoation and description
- `PNRD/`
  - `PNRD_sly_targets.txt`: Targets of the microRNAs for the *S. lycopersicum* species found in PNRD.
  
## Data Sources
- `Planteome`
  - Source : https://planteome.org/
- `PNRD`
  - Source: http://structuralbiology.cau.edu.cn/PNRD/index.php